import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.scss';
import * as tlog from '@tcw/tlog';
import App from './App';

tlog.config.globals.instanceId = crypto.randomUUID();
tlog.config.loggingOp.postToLoggingIngress.ignoreDebug = true;
tlog.config.loggingOp.outputToConsole.ignoreDebug = import.meta.env.VITE_ENV != 'local';

const rootDiv = document.getElementById('root') as HTMLElement;
const root = ReactDOM.createRoot(rootDiv);

tlog.info('Loading web app: ' + import.meta.env.VITE_NAME, 'index.tsx');

document.title =
    import.meta.env.VITE_DISPLAY_NAME ||
    import.meta.env.VITE_APP_NAME ||
    'Aladdin Access Certifications';

root.render(
    <React.StrictMode>
        <App />
    </React.StrictMode>
);
