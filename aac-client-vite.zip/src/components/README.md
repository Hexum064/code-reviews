Add common/shared components here

Recommend separate folder for each component, i.e.

|-- components
    |-- avatar/
        |-- avatar.tsx
        |-- avatar.test.tsx
    |-- split-button
        |-- split-button.scss
        |-- split-button.tsx
        |-- split-button.test.tsx


