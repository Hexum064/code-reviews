   // vite-plugin-eslint.d.ts provided to avoid an annoying error showing up in 
   // vite.config.ts when using vite-plugin-eslint
   // vite-plugin-eslint allows vite to stop execution upon eslint violations.
   declare module 'vite-plugin-eslint';