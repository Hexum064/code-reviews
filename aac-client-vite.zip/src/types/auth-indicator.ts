export type AuthIndicator = {
    resource: string;
    action: string;
    authorized: boolean;
}